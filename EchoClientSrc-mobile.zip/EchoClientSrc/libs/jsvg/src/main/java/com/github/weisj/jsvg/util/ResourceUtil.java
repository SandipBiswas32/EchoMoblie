/*
 * MIT License
 *
 * Copyright (c) 2022-2025 Jannis Weis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */
package com.github.weisj.jsvg.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.github.weisj.jsvg.SVGDocument;
import com.github.weisj.jsvg.logging.Logger;
import com.github.weisj.jsvg.logging.Logger.Level;
import com.github.weisj.jsvg.logging.impl.LogFactory;
import com.github.weisj.jsvg.parser.DomDocument;
import com.github.weisj.jsvg.parser.SVGLoader;
import com.github.weisj.jsvg.parser.resources.RenderableResource;
import com.github.weisj.jsvg.parser.resources.impl.ImageResource;
import com.github.weisj.jsvg.parser.resources.impl.SVGResource;

public final class ResourceUtil {

    private static final Logger LOGGER = LogFactory.createLogger(ResourceUtil.class);

    private ResourceUtil() {}

    private static final Set<String> SUPPORTED_MIME_TYPES = Arrays
            .stream(ImageIO.getReaderFormatNames())
            .map(s -> "image/" + s.toLowerCase(Locale.ENGLISH))
            .collect(Collectors.toSet());

    public static @Nullable RenderableResource loadImage(@NotNull DomDocument document, @NotNull URI uri)
            throws IOException {
        URI resourceUri = document
                .loaderContext()
                .externalResourcePolicy()
                .resolveResourceURI(document.rootURI(), uri);
        if (resourceUri == null) return null;

        String path = resourceUri.getPath();
        if (path != null && path.endsWith(".svg")) {
            SVGLoader loader = new SVGLoader();
            try {
                SVGDocument imageDocument = loader.load(uri.toURL(), document.loaderContext());
                if (imageDocument != null) {
                    return new SVGResource(imageDocument);
                }
            } catch (Exception e) {
                LOGGER.log(Level.WARNING, "Could not load svg resource", e);
            }
        }

        BufferedImage img = loadToBufferedImage(uri);
        if (img == null) return null;
        return new ImageResource(img);
    }

    private static @Nullable BufferedImage loadToBufferedImage(@NotNull URI uri) throws IOException {
        String scheme = uri.getScheme();
        if ("data".equals(scheme)) {
            DataUri dataUri = DataUri.parse(uri.toString(), StandardCharsets.UTF_8);
            if (!isSupportedMimeType(dataUri.mime())) throw new IOException("Unsupported Mime type " + dataUri.mime());
            try (ByteArrayInputStream in = new ByteArrayInputStream(dataUri.data())) {
                return readPossiblyCorruptedFile(in);
            }
        }
        URL url = uri.toURL();
        echo$offlineLocalUrl(url);
        return ImageIO.read(url);
    }

    /** Recovered Echo offline URL check; the embedded method has ACC_SYNTHETIC. */
    private static void echo$offlineLocalUrl(URL url) throws IOException {
        for (int depth = 0; depth < 8; depth++) {
            String protocol = url.getProtocol();
            if ("file".equalsIgnoreCase(protocol)) {
                String host = url.getHost();
                String path;
                try {
                    path = url.toURI().getPath();
                } catch (URISyntaxException cause) {
                    throw new IOException("Invalid local resource URL", cause);
                }
                if ((host != null && !host.isEmpty() && !host.equalsIgnoreCase("localhost"))
                        || path == null || path.replace('\\', '/').startsWith("//")) {
                    break;
                }
                return;
            }
            if (!"jar".equalsIgnoreCase(protocol)) break;
            String archive = url.getFile();
            int separator = archive.indexOf("!/");
            if (separator < 0) break;
            url = new URL(archive.substring(0, separator));
        }
        throw new IOException("Remote resources are unavailable in Echo offline mode");
    }

    private static boolean isSupportedMimeType(@NotNull String mimeType) {
        return SUPPORTED_MIME_TYPES.contains(mimeType.toLowerCase(Locale.ENGLISH));
    }

    private static @Nullable BufferedImage readPossiblyCorruptedFile(@NotNull InputStream inputStream)
            throws IOException {
        ImageInputStream input = ImageIO.createImageInputStream(inputStream);
        Iterator<ImageReader> readers = ImageIO.getImageReaders(input);
        if (!readers.hasNext()) return null;

        ImageReader reader = readers.next();
        reader.setInput(input);

        // Create destination image to hold possibly partially decoded result
        ImageReadParam param = reader.getDefaultReadParam();
        BufferedImage image = reader.getImageTypes(0).next()
                .createBufferedImage(reader.getWidth(0), reader.getHeight(0));
        param.setDestination(image);

        try {
            image = reader.read(0, param);
            // Don't really need the return value here, as it will always be same value
            // as "image"
        } catch (Exception e) {
            // Ignore this exception or display a warning or similar, for exceptions happening during decoding
            LOGGER.log(Level.WARNING, e.getMessage(), e);
        }
        return image;
    }
}
