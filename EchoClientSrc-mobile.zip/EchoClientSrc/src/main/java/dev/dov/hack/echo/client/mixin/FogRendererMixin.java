package dev.dov.hack.echo.client.mixin;

import dev.dov.hack.echo.client.EchoClient;
import dev.dov.hack.echo.client.MinecraftAccess;
import dev.dov.hack.echo.client.modules.impl.render.Ambience;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.FogRenderer;
import net.minecraft.client.world.ClientWorld;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(FogRenderer.class)
public abstract class FogRendererMixin {
    @Inject(method = "applyFog(Lnet/minecraft/client/render/Camera;ILnet/minecraft/client/render/RenderTickCounter;FLnet/minecraft/client/world/ClientWorld;)Lorg/joml/Vector4f;", at = @At("RETURN"), cancellable = true)
    private void onApplyFogReturn(Camera camera, int viewDistance, RenderTickCounter tickCounter, float skyDarkness, ClientWorld world, CallbackInfoReturnable<Vector4f> callback) {
        if (!EchoClient.eventsDisabled && MinecraftAccess.CLIENT.player != null
                && MinecraftAccess.CLIENT.world != null && EchoClient.ModuleManager != null) {
            Ambience ambience = (Ambience) EchoClient.ModuleManager.findFeature(Ambience.class);
            if (ambience != null && ambience.isEnabled() && Ambience.isFogColorEnabled()) {
                float red = Ambience.getFogRed() / 255.0F;
                float green = Ambience.getFogGreen() / 255.0F;
                float blue = Ambience.getFogBlue() / 255.0F;
                callback.setReturnValue(new Vector4f(red, green, blue, 1.0F));
            }
        }
    }

    @ModifyArgs(method = "applyFog(Lnet/minecraft/client/render/Camera;ILnet/minecraft/client/render/RenderTickCounter;FLnet/minecraft/client/world/ClientWorld;)Lorg/joml/Vector4f;", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/fog/FogRenderer;applyFog(Ljava/nio/ByteBuffer;ILorg/joml/Vector4f;FFFFFF)V"))
    private void modifyArgumentsOfApplyFogAtApplyFog(Args arguments) {
        if (!EchoClient.eventsDisabled && MinecraftAccess.CLIENT.player != null
                && MinecraftAccess.CLIENT.world != null && EchoClient.ModuleManager != null) {
            Ambience ambience = (Ambience) EchoClient.ModuleManager.findFeature(Ambience.class);
            if (ambience != null && ambience.isEnabled() && Ambience.isFogColorEnabled()) {
                float red = Ambience.getFogRed() / 255.0F;
                float green = Ambience.getFogGreen() / 255.0F;
                float blue = Ambience.getFogBlue() / 255.0F;
                float distance = Ambience.getFogDistanceChunks() * 16.0F;
                arguments.set(2, new Vector4f(red, green, blue, 1.0F));
                arguments.set(4, distance);
                arguments.set(7, distance);
                arguments.set(8, distance);
            }
        }
    }
}
