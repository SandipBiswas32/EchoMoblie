package dev.dov.hack.echo.client.handlers;

import dev.dov.hack.echo.client.event.Subscribe;
import dev.dov.hack.echo.client.event.lifecycle.ClientTickEvent;
import dev.dov.hack.echo.client.event.network.PacketReceiveEvent;
import dev.dov.hack.echo.client.utils.network.PlayerLatency;
import java.util.Arrays;
import net.minecraft.network.packet.c2s.query.QueryPingC2SPacket;
import net.minecraft.network.packet.s2c.query.PingResultS2CPacket;
import net.minecraft.util.Util;

public final class LatencyTracker extends ClientHandler {
    private static final int PROBE_INTERVAL_TICKS = 10;
    private static final int SAMPLE_CAPACITY = 5;
    private static final long STALE_AFTER_MILLIS = 5_000L;
    private static final int[] samples = new int[SAMPLE_CAPACITY];
    private static int writeIndex;
    private static int sampleCount;
    private static volatile int medianMillis = -1;
    private static volatile long lastSampleMillis;
    private int ticks;

    public static int milliseconds() {
        int measured = medianMillis;
        if (measured < 0 || Util.getMeasuringTimeMs() - lastSampleMillis > STALE_AFTER_MILLIS) {
            return PlayerLatency.milliseconds();
        }
        return measured;
    }

    @Subscribe
    private void onTick(ClientTickEvent event) {
        if (CLIENT.player == null || CLIENT.getNetworkHandler() == null) {
            clearSamples();
            return;
        }
        if (CLIENT.getDebugHud().shouldShowPacketSizeAndPingCharts()) {
            return;
        }
        if (++ticks % PROBE_INTERVAL_TICKS != 0) {
            return;
        }
        CLIENT.getNetworkHandler().sendPacket(new QueryPingC2SPacket(Util.getMeasuringTimeMs()));
    }

    @Subscribe
    private void onPacketReceived(PacketReceiveEvent event) {
        if (event.getPacket() instanceof PingResultS2CPacket pong) {
            recordSample((int) (Util.getMeasuringTimeMs() - pong.startTime()));
        }
    }

    private static synchronized void recordSample(int elapsedMillis) {
        if (elapsedMillis < 0) {
            return;
        }
        samples[writeIndex] = elapsedMillis;
        writeIndex = (writeIndex + 1) % SAMPLE_CAPACITY;
        if (sampleCount < SAMPLE_CAPACITY) {
            sampleCount++;
        }
        int[] ordered = Arrays.copyOf(samples, sampleCount);
        Arrays.sort(ordered);
        medianMillis = ordered[sampleCount / 2];
        lastSampleMillis = Util.getMeasuringTimeMs();
    }

    private static synchronized void clearSamples() {
        writeIndex = 0;
        sampleCount = 0;
        medianMillis = -1;
    }
}
